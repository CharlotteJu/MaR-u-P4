package com.example.mareu.Controler.Ui;

public class ReunionListRecyclerViewAdapter
{
}
